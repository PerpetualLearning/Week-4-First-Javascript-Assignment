function aboutMeInfo(name, height, country) {
        alert(name + '' + '' + height + ''+ country)
};


aboutMeInfo("Jessica", "5'8", "USA");
