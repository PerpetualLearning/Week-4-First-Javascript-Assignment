function basketBallPlayer(name, height, country) {
    alert("name" +  "height" +  "country");

};
basketBallPlayer("Michael", "6'6", "USA");



